"""
WHATSAPP WEB BOT v3 (Hermes Trismegistus Edition)
Blast masivo desde WhatsApp Web con lista de numeros.
"""
from __future__ import annotations
import time, random, json, os, logging
from dataclasses import dataclass, asdict

import undetected_chromedriver as uc
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger("whatsapp")

@dataclass
class Config:
    messages: list = None
    min_wait: tuple = (30, 60)
    numbers_file: str = "wa_numeros.txt"
    data_file: str = "wa_state.json"
    headless: bool = False

    def __post_init__(self):
        self.messages = self.messages or [
            "Hola! Te contacto porque vi que andas buscando oportunidades de trabajo. Yo entre a Outlier, una pagina donde pagan por evaluar IA. Sin experiencia, desde casa, en USD. Te interesa?",
            "Que tal! Ando pasando el dato de Outlier, una plataforma donde estoy generando billete evaluando IA. Si quieres el link de referido me avisas!",
            "Hola! Perdon si molesto. Me llamo Gael y estoy ayudando a personas a entrar a Outlier, una pagina donde pagan por evaluar IA. Sin experiencia y desde casa. Si te interesa te paso info!",
            "Buenas! Ando reclutando para Outlier, una pagina de IA que paga en USD. Yo ya saque lana y busco referidos. Si quieres el link mandame mensaje 👍",
        ]

@dataclass
class State:
    total: int = 0
    sent: list = None
    def __post_init__(self):
        if self.sent is None: self.sent = []
    def save(self, p): json.dump(asdict(self), open(p, "w"), indent=2)
    @classmethod
    def load(cls, p):
        try: return cls(**json.load(open(p)))
        except: return cls()

def create_driver(cfg):
    opts = uc.ChromeOptions()
    opts.add_argument("--window-size=1280,800")
    opts.add_argument("--lang=es")
    opts.add_argument("--disable-blink-features=AutomationControlled")
    d = uc.Chrome(options=opts, headless=cfg.headless, version_main=126)
    d.set_page_load_timeout(30)
    return d

def random_delay(a=0.3, b=1.5): time.sleep(random.uniform(a, b))
def human_type(el, t):
    for c in t:
        el.send_keys(c); time.sleep(random.uniform(0.02, 0.07))
    random_delay(0.3, 0.6)

def run():
    cfg = Config()
    state = State.load(cfg.data_file)
    driver = create_driver(cfg)

    driver.get("https://web.whatsapp.com")
    input("👉 Escanea QR de WhatsApp Web con tu celular y presiona ENTER...")
    random_delay(5, 8)

    # Cargar numeros
    if os.path.exists(cfg.numbers_file):
        with open(cfg.numbers_file) as f:
            nums = [l.strip() for l in f if l.strip()]
    else:
        inp = input("👉 Pega numeros (separados por coma, formato +521234567890): ")
        nums = [n.strip() for n in inp.split(",") if n.strip()]
        with open(cfg.numbers_file, "w") as f:
            f.write("\n".join(nums))

    nums = [n for n in nums if n not in state.sent]
    log.info(f"🔥 Numero a enviar: {len(nums)} (de {len(nums)+len(state.sent)} totales)")

    for num in nums:
        try:
            driver.get(f"https://web.whatsapp.com/send?phone={num.lstrip('+')}")
            random_delay(5, 10)

            caja = WebDriverWait(driver, 20).until(
                EC.presence_of_element_located((By.CSS_SELECTOR,
                    'div[contenteditable="true"][role="textbox"]'))
            )

            texto = random.choice(cfg.messages)
            human_type(caja, texto)
            random_delay(0.5, 1.5)
            caja.send_keys(Keys.ENTER)
            state.total += 1
            state.sent.append(num)
            state.save(cfg.data_file)
            log.info(f"📱 #{state.total} WA a {num}")

            time.sleep(random.uniform(*cfg.min_wait))

        except Exception as e:
            log.warning(f"✗ {num}: {e}")
            continue

    log.info(f"\n✅ Total WA: {state.total}/{len(nums)+len(state.sent)}")
    driver.quit()

if __name__ == "__main__":
    run()
