@echo off
chcp 65001 >nul
title MEGA BOTS v3 - Hermes Edition
cls
echo 🔥 MEGA BOTS LAUNCHER v3 (Hermes Trismegistus) 🔥
echo ================================================
echo 1) TikTok Comment Bomb
echo 2) YouTube Comment Bot
echo 3) Instagram DM Bot
echo 4) Facebook Auto-Poster
echo 5) WhatsApp Web Blast
echo 6) CORRER TODOS EN VENTANAS SEPARADAS
echo ================================================
set /p opt="Elige (1-6): "

if "%opt%"=="1" start "TikTok" cmd /k python tiktok_bot.py
if "%opt%"=="2" start "YouTube" cmd /k python yt_bot.py
if "%opt%"=="3" start "Instagram" cmd /k python ig_bot.py
if "%opt%"=="4" start "Facebook" cmd /k python fb_bot.py
if "%opt%"=="5" start "WhatsApp" cmd /k python wa_bot.py
if "%opt%"=="6" (
    start "TikTok" cmd /k python tiktok_bot.py
    start "YouTube" cmd /k python yt_bot.py
    start "Instagram" cmd /k python ig_bot.py
    start "Facebook" cmd /k python fb_bot.py
    start "WhatsApp" cmd /k python wa_bot.py
    echo Todos lanzados en ventanas separadas
)
pause
