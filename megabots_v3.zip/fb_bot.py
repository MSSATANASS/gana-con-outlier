"""
FACEBOOK GROUP POST BOT v3 (Hermes Trismegistus Edition)
Publica en grupos de empleo/trabajo automaticamente.
"""
from __future__ import annotations
import time, random, json, os, logging
from datetime import datetime
from dataclasses import dataclass, asdict

import undetected_chromedriver as uc
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger("facebook")

@dataclass
class Config:
    groups: list = None
    posts: list = None
    min_wait: tuple = (600, 1800)  # 10-30 min entre posts
    data_file: str = "fb_state.json"
    headless: bool = False

    def __post_init__(self):
        self.groups = self.groups or [
            "trabajodesdecasamexico", "empleosremotosmexico",
            "trabajoparalatinos", "freelancersmexico",
            "trabajodesdecasacolombia", "trabajodesdecasachile",
            "empleosremotoslatam", "trabajofreelancemx",
        ]
        self.posts = self.posts or [
            "Gente! Alguien conoce Outlier? Es una pagina donde pagan por evaluar IA. Yo entre hace poco y ya voy sacando lana sin experiencia. Les paso el link por DM si les interesa 💰",
            "Ando generando billete con una pagina de IA llamada Outlier. Sin experiencia, desde casa, pagan en USD. Si alguien quiere el link de referido mandenme mensaje 👍",
            "Buen dia! Les recomiendo Outlier si buscan ingresos extra. Pagan por evaluar IA, desde casa, sin experiencia. Yo ya saque dolares mi primera semana. DM si quieren link 🤙",
            "Para el que busca chamba remota: Outlier busca evaluadores de IA. Paga en USD, sin experiencia necesaria. Manden DM si quieren el link de referido 🔥",
        ]

@dataclass
class State:
    total: int = 0
    group_idx: int = 0
    last_time: str = ""
    posted_groups: list = None
    def __post_init__(self):
        if self.posted_groups is None: self.posted_groups = []
    def save(self, p): json.dump(asdict(self), open(p, "w"), indent=2)
    @classmethod
    def load(cls, p):
        try: return cls(**json.load(open(p)))
        except: return cls()

def create_driver(cfg):
    opts = uc.ChromeOptions()
    opts.add_argument("--window-size=1366,768")
    opts.add_argument("--lang=es")
    opts.add_argument("--disable-blink-features=AutomationControlled")
    d = uc.Chrome(options=opts, headless=cfg.headless, version_main=126)
    d.set_page_load_timeout(30)
    d.execute_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
    return d

def random_delay(a=0.3, b=1.5): time.sleep(random.uniform(a, b))
def human_type(el, t):
    for c in t:
        el.send_keys(c); time.sleep(random.uniform(0.02, 0.06))
    random_delay(0.3, 0.6)

def run():
    cfg = Config()
    state = State.load(cfg.data_file)
    driver = create_driver(cfg)

    driver.get("https://www.facebook.com")
    random_delay(3, 5)
    cfile = cfg.data_file.replace("state", "cookies")
    if os.path.exists(cfile):
        with open(cfile) as f: cks = json.load(f)
        for c in cks:
            try: driver.add_cookie(c)
            except: pass
        driver.refresh(); random_delay(3, 5)
    else:
        input("👉 Logeate en Facebook y presiona ENTER...")
        json.dump(driver.get_cookies(), open(cfile, "w"))

    log.info("🔥 FACEBOOK BOT v3 ACTIVADO")
    try:
        while True:
            for gi in range(state.group_idx, len(cfg.groups)):
                grp = cfg.groups[gi]
                if grp in (state.posted_groups or []):
                    continue
                state.group_idx = gi
                log.info(f"\n📝 Grupo: {grp}")

                try:
                    driver.get(f"https://www.facebook.com/groups/{grp}/")
                    random_delay(4, 7)

                    # Buscar caja de texto
                    caja = None
                    for sel in [
                        'div[role="textbox"]',
                        'div[aria-label*="Escribe" i]',
                        'div[aria-label*="Comparte" i]',
                        'div[contenteditable="true"]',
                        'div[class*="mentions"]',
                    ]:
                        try:
                            caja = WebDriverWait(driver, 5).until(
                                EC.element_to_be_clickable((By.CSS_SELECTOR, sel))
                            )
                            if caja.is_displayed(): break
                        except:
                            continue

                    if not caja:
                        log.warning("No caja de texto encontrada"); continue

                    ActionChains(driver).move_to_element(caja).click().perform()
                    random_delay(1, 2)
                    texto = random.choice(cfg.posts)
                    human_type(caja, texto)
                    random_delay(1, 2)

                    # Click Publicar
                    for sel in ['div[aria-label="Publicar" i]', 'div[role="button"]', 'button']:
                        try:
                            btns = driver.find_elements(By.CSS_SELECTOR, sel)
                            for b in btns:
                                if "publicar" in b.text.lower() or "publish" in b.text.lower():
                                    b.click(); break
                            else: continue
                            break
                        except: continue

                    state.total += 1
                    if state.posted_groups is None: state.posted_groups = []
                    state.posted_groups.append(grp)
                    state.last_time = datetime.now().isoformat()
                    state.save(cfg.data_file)
                    log.info(f"✅ Post #{state.total} en {grp}")

                    time.sleep(random.uniform(*cfg.min_wait))

                except Exception as e:
                    log.warning(f"Error en {grp}: {e}")
                    continue

            state.group_idx = 0
            state.posted_groups = []
            log.info("⏳ Todos los grupos posteados. Ciclo completo.")
            time.sleep(random.uniform(3600, 7200))

    finally:
        driver.quit(); state.save(cfg.data_file)
        log.info("👋 Fin FB")

if __name__ == "__main__":
    run()
