"""
YOUTUBE COMMENT BOT v3 (Hermes Trismegistus Edition)
Stealth mode, multi-selector fallback, auto-resume.
"""
from __future__ import annotations
import time, random, json, os, logging
from datetime import datetime
from dataclasses import dataclass, asdict

import undetected_chromedriver as uc
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import *

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger("youtube")

@dataclass
class Config:
    queries: list = None
    comments: list = None
    videos_per_query: int = 3
    min_wait: tuple = (45, 120)
    data_file: str = "yt_state.json"
    headless: bool = False

    def __post_init__(self):
        self.queries = self.queries or [
            "trabajo desde casa 2026", "cómo ganar dinero desde casa",
            "ingresos extra latinoamerica", "freelancer principiantes",
            "trabajo remoto sin experiencia", "ganar dinero por internet",
            "empleo desde casa Mexico", "trabajo online Colombia",
            "negocio desde cero", "trabajo freelance latinos",
            "como generar ingresos pasivos", "trabajo medio tiempo",
        ]
        self.comments = self.comments or [
            "Si buscan algo mas, yo entre a Outlier y ya saque billete evaluando IA. Link en mi perfil 👍",
            "Buen video! Yo tambien ando generando con Outlier, recomendado para el que busca ingresos extra 🔥",
            "Yo probe varias paginas y Outlier es la que mejor me ha ido. Si quieren el link manden DM 🤙",
            "Alguien conoce Outlier? Es una plataforma donde pagan por evaluar IA. Sin experiencia y desde casa 💰",
            "Para el que busca ingresos: Outlier paga en USD. Link en mi perfil, cualquier duda DM 🔥",
        ]

@dataclass
class State:
    total: int = 0
    query_idx: int = 0
    last_time: str = ""
    def save(self, p): json.dump(asdict(self), open(p, "w"), indent=2)
    @classmethod
    def load(cls, p):
        try: return cls(**json.load(open(p)))
        except: return cls()

def create_driver(cfg):
    opts = uc.ChromeOptions()
    opts.add_argument("--window-size=1280,800")
    opts.add_argument("--lang=es")
    opts.add_argument("--no-first-run")
    opts.add_argument("--disable-blink-features=AutomationControlled")
    opts.add_argument("--mute-audio")
    d = uc.Chrome(options=opts, headless=cfg.headless, version_main=126)
    d.set_page_load_timeout(30)
    d.execute_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
    return d

def random_delay(a=0.3, b=1.5): time.sleep(random.uniform(a, b))
def human_type(el, t):
    for c in t:
        el.send_keys(c); time.sleep(random.uniform(0.02, 0.08))
    random_delay(0.2, 0.5)

def run():
    cfg = Config()
    state = State.load(cfg.data_file)
    driver = create_driver(cfg)

    # Login o cookies
    driver.get("https://www.youtube.com")
    random_delay(3, 5)
    cfile = cfg.data_file.replace("state", "cookies")
    if os.path.exists(cfile):
        json.load(open(cfile))
        driver.refresh(); random_delay(3, 5)
    else:
        input("👉 Logeate en YouTube y presiona ENTER...")
        json.dump(driver.get_cookies(), open(cfile, "w"))

    log.info("🔥 YOUTUBE BOT v3 ACTIVADO")
    try:
        while True:
            for qi in range(state.query_idx if state.query_idx else 0, len(cfg.queries)):
                q = cfg.queries[qi]
                state.query_idx = qi
                log.info(f"\n🔍 Buscando: {q}")
                driver.get(f"https://www.youtube.com/results?search_query={q.replace(' ', '+')}&sp=CAI%3D")  # ultimo año
                random_delay(3, 6)

                links = []
                for v in driver.find_elements(By.ID, "video-title"):
                    h = v.get_attribute("href")
                    if h: links.append(h)
                random.shuffle(links)
                log.info(f"   {len(links)} videos")

                for url in links[:cfg.videos_per_query]:
                    try:
                        driver.get(url)
                        random_delay(3, 5)
                        driver.execute_script("window.scrollBy(0, 300)")
                        random_delay(1, 2)

                        # Click caja de comentarios
                        caja = None
                        for sel in ['#simplebox-placeholder', '#placeholder-area', 'div[contenteditable="true"]']:
                            try:
                                el = WebDriverWait(driver, 3).until(EC.element_to_be_clickable((By.CSS_SELECTOR, sel)))
                                caja = el; break
                            except: continue

                        if not caja:
                            log.warning("No caja de comentarios")
                            continue

                        ActionChains(driver).move_to_element(caja).click().perform()
                        random_delay(1, 2)
                        editor = driver.find_element(By.CSS_SELECTOR, "#contenteditable-root")
                        texto = random.choice(cfg.comments)
                        human_type(editor, texto)
                        random_delay(0.5, 1)
                        editor.send_keys(Keys.ENTER)
                        state.total += 1
                        state.last_time = datetime.now().isoformat()
                        state.save(cfg.data_file)
                        log.info(f"💬 #{state.total}: {texto[:30]}...")

                        time.sleep(random.uniform(*cfg.min_wait))
                    except Exception as e:
                        log.warning(f"Video error: {e}")
                        continue

            state.query_idx = 0
            log.info(f"⏳ Ciclo completo, esperando...")
            time.sleep(random.uniform(300, 600))

    finally:
        driver.quit(); state.save(cfg.data_file)
        log.info("👋 Fin")

if __name__ == "__main__":
    run()
