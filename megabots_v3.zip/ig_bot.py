"""
INSTAGRAM DM BOT v3 (Hermes Trismegistus Edition)
Stealth DM a seguidores de cuentas de trabajo.
"""
from __future__ import annotations
import time, random, json, os, logging
from datetime import datetime
from dataclasses import dataclass, asdict

import undetected_chromedriver as uc
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger("instagram")

@dataclass
class Config:
    accounts: list = None
    messages: list = None
    dms_per_account: int = 4
    min_wait: tuple = (60, 120)
    data_file: str = "ig_state.json"
    headless: bool = False

    def __post_init__(self):
        self.accounts = self.accounts or [
            "trabajosremotos", "freelancerlatam", "ganardinero",
            "trabajodesdecasa", "empleosremotos", "latinosfreelance",
            "trabajomx", "trabajoslatinos", "oportunidadesempleo",
        ]
        self.messages = self.messages or [
            "Hola! Vi que te interesa el trabajo remoto. Yo entre a Outlier y estoy generando lana evaluando IA. Te paso el link si quieres!",
            "Que tal! Andas buscando ingresos extra? Yo entre a una pagina de IA y ya saque mis primeros 200usd. Te interesa el dato?",
            "Hola! Perdon si molesto, vi tu perfil y veo que te interesa el trabajo freelance. Yo estoy en Outlier y me ha ido bien, si quieres el link avisame!",
        ]

@dataclass
class State:
    total: int = 0
    account_idx: int = 0
    sent_to: list = None
    def __post_init__(self):
        if self.sent_to is None: self.sent_to = []
    def save(self, p): json.dump(asdict(self), open(p, "w"), indent=2)
    @classmethod
    def load(cls, p):
        try: return cls(**json.load(open(p)))
        except: return cls()

def create_driver(cfg):
    opts = uc.ChromeOptions()
    opts.add_argument("--window-size=1280,800")
    opts.add_argument("--lang=es")
    opts.add_argument("--disable-blink-features=AutomationControlled")
    d = uc.Chrome(options=opts, headless=cfg.headless, version_main=126)
    d.set_page_load_timeout(30)
    d.execute_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
    return d

def random_delay(a=0.3, b=1.5): time.sleep(random.uniform(a, b))
def human_type(el, t):
    for c in t:
        el.send_keys(c); time.sleep(random.uniform(0.03, 0.09))
    random_delay(0.3, 0.7)

def run():
    cfg = Config()
    state = State.load(cfg.data_file)
    driver = create_driver(cfg)

    driver.get("https://www.instagram.com")
    random_delay(3, 5)
    cfile = cfg.data_file.replace("state", "cookies")
    if os.path.exists(cfile):
        with open(cfile) as f: cks = json.load(f)
        for c in cks:
            try: driver.add_cookie(c)
            except: pass
        driver.refresh(); random_delay(3, 5)
    else:
        input("👉 Logeate en Instagram y presiona ENTER...")
        json.dump(driver.get_cookies(), open(cfile, "w"))

    log.info("🔥 INSTAGRAM DM v3 ACTIVADO")
    try:
        while True:
            for ai in range(state.account_idx, len(cfg.accounts)):
                ac = cfg.accounts[ai]
                state.account_idx = ai
                log.info(f"\n📂 Cuenta: {ac}")

                try:
                    driver.get(f"https://www.instagram.com/{ac}/")
                    random_delay(3, 5)

                    # Click en followers
                    followers_link = None
                    for sel in ['a[href$="/followers/"]', 'a[href*="/followers/"]']:
                        try:
                            followers_link = driver.find_element(By.CSS_SELECTOR, sel)
                            break
                        except: continue
                    if not followers_link:
                        log.warning("No followers link"); continue

                    followers_link.click()
                    random_delay(3, 5)

                    # Scroll en modal de seguidores
                    modal = None
                    for sel in ['div[role="dialog"]', 'div[class*="followers"]']:
                        try:
                            modal = driver.find_element(By.CSS_SELECTOR, sel)
                            break
                        except: continue

                    if not modal: continue

                    # Scroll multiple pa' cargar mas
                    for _ in range(3):
                        driver.execute_script("arguments[0].scrollTop = arguments[0].scrollHeight", modal)
                        random_delay(1, 2)

                    # Conseguir usuarios
                    users = set()
                    for a in driver.find_elements(By.CSS_SELECTOR, 'a[href^="/"]'):
                        h = a.get_attribute("href")
                        if h and len(h.split("/")) == 4 and h not in state.sent_to:
                            users.add(h)
                    users = list(users)
                    random.shuffle(users)
                    log.info(f"   {len(users)} targets")

                    for url in users[:cfg.dms_per_account]:
                        username = url.split("/")[-2]
                        if url in state.sent_to: continue

                        try:
                            driver.get(f"{url}")
                            random_delay(2, 4)

                            # Boton de mensaje
                            msg_btn = None
                            for sel in ['div[role="button"]', 'button']:
                                els = driver.find_elements(By.CSS_SELECTOR, sel)
                                for el in els:
                                    if "Mensaje" in el.text or "Message" in el.text:
                                        msg_btn = el; break
                                if msg_btn: break

                            if not msg_btn:
                                log.info(f"   🔒 {username} no acepta DMs"); continue

                            msg_btn.click()
                            random_delay(2, 3)

                            caja = driver.find_element(By.CSS_SELECTOR, 'textarea, div[contenteditable="true"][role="textbox"]')
                            texto = random.choice(cfg.messages)
                            human_type(caja, texto)
                            random_delay(0.5, 1)
                            caja.send_keys(Keys.ENTER)
                            state.total += 1
                            state.sent_to.append(url)
                            state.save(cfg.data_file)
                            log.info(f"📨 #{state.total} DM a {username}")

                            time.sleep(random.uniform(*cfg.min_wait))

                        except Exception as e:
                            log.warning(f"   Error con {username}: {e}")
                            continue

                except Exception as e:
                    log.warning(f"Error con cuenta {ac}: {e}")
                    continue

            state.account_idx = 0
            log.info("⏳ Ciclo IG completo")
            time.sleep(random.uniform(600, 1200))

    finally:
        driver.quit(); state.save(cfg.data_file)
        log.info("👋 Fin IG")

if __name__ == "__main__":
    run()
