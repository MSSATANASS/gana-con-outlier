"""
TIKTOK COMMENT BOMB v3 (Hermes Trismegistus Edition)
Anti-ban, stealth mode, selector fallbacks, auto-resume.
"""
from __future__ import annotations
import time, random, json, os, sys, re, logging
from datetime import datetime
from pathlib import Path
from typing import Optional
from dataclasses import dataclass, asdict

import undetected_chromedriver as uc
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import *

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger("tiktok")

# ── C O N F I G ─────────────────────────────────────────────────────
@dataclass
class Config:
    hashtags: list = None
    comments: list = None
    comments_per_hashtag: int = 4
    min_wait: tuple = (45, 120)        # seg entre comentarios
    cycle_wait: tuple = (300, 600)     # seg entre hashtags
    max_comments_per_session: int = 0  # 0 = ilimitado
    data_file: str = "tiktok_state.json"
    headless: bool = False
    proxy: str = ""

    def __post_init__(self):
        self.hashtags = self.hashtags or [
            "trabajo", "dinero", "freelancer", "trabajodesdecasa",
            "ingresosextras", "latinos", "mexico", "colombia",
            "argentina", "empleo", "trabajoremoto", "paratodos",
            "oportunidad", "trabajoporinternet",
        ]
        self.comments = self.comments or [
            "Yo entre a Outlier y ya saque 200usd mi primera semanita sin experiencia🔥 manden DM si quieren el link",
            "Alguien mas conociendo Outlier? Yo entre por un compa y ya voy generando billete 👇 link en mi bio",
            "Si buscan jale desde casa, yo entre a Outlier y si cae la feria. Manden DM les paso el link 👍",
            "Yo estaba bien jodido hasta que probe esto de evaluar IA. Mi primera semana saque 150usd. DM si quieren el dato",
            "Para los que buscan ingresos extra: Outlier paga en USD por evaluar IA. Sin experiencia. Link en mi perfil",
            "Yo tambien ando en esto del trabajo remoto. Outlier me ha ido bien, si quieren el link manden DM 💰",
            "Alguien probando Outlier? Yo entre y ya voy generando lana los ratos libres. Link en mi bio 🔥",
            "No sabia que existia esto de evaluar IA, un amigo me metio y ya saque mis primeros dolares. DM y les paso el link",
            "Para morros que buscan lana extra: Outlier paga en USD. Sin experiencia, desde tu casa. Link en mi perfil",
            "Hola! Yo entre a Outlier y estoy generando ingresos extra. Si quieren el link de referido manden mensaje 🤙",
        ]


# ── S T E A L T H   D R I V E R ─────────────────────────────────────
def create_driver(cfg: Config) -> uc.Chrome:
    opts = uc.ChromeOptions()
    opts.add_argument("--window-size=1280,800")
    opts.add_argument("--disable-notifications")
    opts.add_argument("--lang=es")
    opts.add_argument("--no-first-run")
    opts.add_argument("--disable-blink-features=AutomationControlled")
    opts.add_argument("--mute-audio")
    if cfg.proxy:
        opts.add_argument(f"--proxy-server={cfg.proxy}")

    driver = uc.Chrome(options=opts, headless=cfg.headless, version_main=126)
    driver.set_page_load_timeout(30)

    # Stealth: ocultar automatizacion
    driver.execute_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
    driver.execute_cdp_cmd("Network.setUserAgentOverride", {
        "userAgent": random.choice([
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
        ])
    })
    return driver


# ── S T A T E ───────────────────────────────────────────────────────
@dataclass
class State:
    total_comments: int = 0
    current_hashtag_idx: int = 0
    completed_hashtags: list = None
    last_comment_time: str = ""

    def save(self, path: str):
        with open(path, "w") as f:
            json.dump(asdict(self), f, indent=2)

    @classmethod
    def load(cls, path: str):
        try:
            with open(path) as f:
                return cls(**json.load(f))
        except: return cls()


# ── H U M A N   B E H A V I O R ─────────────────────────────────────
def random_delay(a: float = 0.3, b: float = 1.5) -> None:
    time.sleep(random.uniform(a, b))

def human_type(element, text: str):
    """Escribe como humano, con pausas variables."""
    for char in text:
        element.send_keys(char)
        time.sleep(random.uniform(0.03, 0.12))
    random_delay(0.2, 0.5)

def random_scroll(driver):
    """Scroll aleatorio para simular humano."""
    for _ in range(random.randint(1, 3)):
        driver.execute_script(f"window.scrollBy(0, {random.randint(100, 400)})")
        random_delay(0.5, 1.5)


# ── S E L E C T O R   F A L L B A C K ──────────────────────────────
def find_element(driver, selectors: list, timeout: int = 5):
    """Prueba múltiples selectores hasta encontrar uno."""
    for sel in selectors:
        try:
            el = WebDriverWait(driver, timeout).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, sel))
            )
            if el.is_displayed():
                return el
        except: continue
    return None

def wait_clickable(driver, selectors: list, timeout: int = 5):
    """Espera a que un elemento sea clickeable."""
    for sel in selectors:
        try:
            return WebDriverWait(driver, timeout).until(
                EC.element_to_be_clickable((By.CSS_SELECTOR, sel))
            )
        except: continue
    return None


# ── C O R E ─────────────────────────────────────────────────────────
def comment_on_video(driver, url: str, texto: str) -> bool:
    try:
        driver.get(url)
        random_delay(3, 6)
        random_scroll(driver)

        # Buscar caja de comentarios con fallbacks
        comment_selectors = [
            'div[contenteditable="true"]',
            'textarea',
            'input[placeholder*="coment" i]',
            'div[data-placeholder*="coment" i]',
            'div[class*="comment"][contenteditable]',
            'div[class*="DraftEditor"]',
        ]
        caja = find_element(driver, comment_selectors, timeout=5)
        if not caja:
            # Click en icono de comentarios
            icon_selectors = [
                'svg[data-e2e="comment"]',
                'button[data-e2e*="comment"]',
                'div[class*="comment"][role="button"]',
            ]
            icon = wait_clickable(driver, icon_selectors, timeout=3)
            if icon:
                icon.click()
                random_delay(1, 2)
                caja = find_element(driver, comment_selectors, timeout=5)

        if not caja:
            log.warning(f"No se encontro caja de comentarios en {url[:50]}")
            return False

        # Click y escribir como humano
        actions = ActionChains(driver)
        actions.move_to_element(caja).click().perform()
        random_delay(0.5, 1)
        caja.clear()
        human_type(caja, texto)
        random_delay(0.5, 1.5)
        caja.send_keys(Keys.ENTER)
        log.info(f"💬 Comentado: {texto[:40]}...")
        return True

    except Exception as e:
        log.warning(f"Error al comentar: {e}")
        return False


def login_or_restore(driver, cfg: Config):
    """Intenta restaurar sesion o pide login manual."""
    cookie_file = cfg.data_file.replace("state", "cookies")
    driver.get("https://www.tiktok.com")
    random_delay(3, 5)

    if os.path.exists(cookie_file):
        with open(cookie_file) as f:
            cks = json.load(f)
        for c in cks:
            try: driver.add_cookie(c)
            except: pass
        driver.refresh()
        random_delay(3, 5)
        log.info("🍪 Cookies restauradas")
        return

    input("🔐 Logeate en TikTok (QR/correo) y presiona ENTER...")
    with open(cookie_file, "w") as f:
        json.dump(driver.get_cookies(), f, indent=2)
    log.info("✅ Cookies guardadas")


def run():
    cfg = Config()
    state = State.load(cfg.data_file)
    driver = create_driver(cfg)

    try:
        login_or_restore(driver, cfg)
        log.info("🔥 TIKTOK BOMB v3 ACTIVADA (Hermes Edition)")

        while True:
            # Rotar hashtags desde donde nos quedamos
            for i in range(state.current_hashtag_idx, len(cfg.hashtags)):
                ht = cfg.hashtags[i]
                state.current_hashtag_idx = i
                url = f"https://www.tiktok.com/tag/{ht}"
                log.info(f"\n🎯 #{ht} ({i+1}/{len(cfg.hashtags)})")

                try:
                    driver.get(url)
                    random_delay(3, 6)
                    driver.execute_script("window.scrollBy(0, 300)")
                    random_delay(2, 3)

                    # Obtener links de videos
                    video_links = set()
                    for a in driver.find_elements(By.TAG_NAME, "a"):
                        h = a.get_attribute("href")
                        if h and "/video/" in h:
                            video_links.add(h)
                    video_links = list(video_links)
                    random.shuffle(video_links)
                    log.info(f"   {len(video_links)} videos encontrados")

                    for vurl in video_links[:cfg.comments_per_hashtag]:
                        if cfg.max_comments_per_session and state.total_comments >= cfg.max_comments_per_session:
                            log.info(f"🏁 Limite de {cfg.max_comments_per_session} comentarios alcanzado")
                            state.save(cfg.data_file)
                            return

                        texto = random.choice(cfg.comments)
                        ok = comment_on_video(driver, vurl, texto)
                        if ok:
                            state.total_comments += 1
                            state.last_comment_time = datetime.now().isoformat()
                            state.save(cfg.data_file)
                            log.info(f"   TOTAL: {state.total_comments}")

                        pausa = random.uniform(*cfg.min_wait)
                        log.info(f"   ⏳ {pausa:.0f}s hasta siguiente...")
                        time.sleep(pausa)

                except Exception as e:
                    log.warning(f"⚠️ Error en #{ht}: {e}")
                    continue

            state.current_hashtag_idx = 0
            pausa_ciclo = random.uniform(*cfg.cycle_wait)
            log.info(f"\n🔄 Ciclo completo. Pausa de {pausa_ciclo:.0f}s...")
            time.sleep(pausa_ciclo)

    finally:
        driver.quit()
        state.save(cfg.data_file)
        log.info("👋 Driver cerrado. Estado guardado.")


if __name__ == "__main__":
    run()
